package java25.jep505_structured_concurrency;

import java.util.List;

public record Proposal(String hotel, List<String> carRentals) {
}
