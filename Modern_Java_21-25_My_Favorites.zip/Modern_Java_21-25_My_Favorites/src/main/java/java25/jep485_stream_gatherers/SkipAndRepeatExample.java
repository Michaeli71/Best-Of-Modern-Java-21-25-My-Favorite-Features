package java25.jep485_stream_gatherers;

import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Gatherer;
import java.util.stream.Stream;

public class SkipAndRepeatExample {

    static void main() {
        IO.println(Stream.of("This", "is", "a", "test", "A", "B", "C").
                gather(skipAndRepeat(0, 2)).
                toList());

        IO.println(Stream.of(1, 2, 3, 4, 5, 6, 7).
                gather(skipAndRepeat(4, 3)).
                toList());
    }

    public static <T> Gatherer<T, AtomicInteger, T> skipAndRepeat(int skip, int times) {
        return Gatherer.ofSequential(
                AtomicInteger::new,
                (state, element, downstream) -> {
                    int idx = state.getAndIncrement();
                    if (idx >= skip) {
                        boolean accepting = true;
                        for (int i = 0; i < times && accepting; i++) {
                            accepting = downstream.push(element);
                        }
                        return accepting; // false => sofortige Beendigung nach unten/oben
                    }
                    return true; // noch in der Skip-Phase: nichts emittiert, aber weiterlesen
                }
        );
    }
}
