package java25.jep485_stream_gatherers;

import java.util.stream.Gatherers;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class MapConcurrentExample {
    public static void main(String[] args)
    {
        IO.println(Stream.of(1, 2, 3, 4, 5, 6, 7, 8, 9, 10).
                gather(Gatherers.mapConcurrent(5, x -> x * x)).
                toList());

        Stream.of(1, 2, 3, 4, 5, 6, 7, 8, 9, 10).
                parallel().
                map(x -> x * x).
                toList();


        var result3 = IntStream.rangeClosed(0, 499).
                boxed().
                parallel().
                map(LookupService::lookup).
                toList();
        IO.println(result3);
        var result4 = IntStream.rangeClosed(0, 499).
                boxed().
                gather(Gatherers.mapConcurrent(250,
                       LookupService::lookup)).
                toList();
        IO.println(result4);
        var result5 = IntStream.rangeClosed(0, 499).
                boxed().
                gather(Gatherers.mapConcurrent(500,
                        LookupService::lookup)).
                toList();
        IO.println(result5);

        // Faktor 100, aber immer noch 1 Sekunde
        var result6 = IntStream.rangeClosed(0, 49999).
                boxed().
                gather(Gatherers.mapConcurrent(50000,
                        LookupService::lookup)).
                toList();

        IO.println(result5);
    }

    static class LookupService
    {
        static int lookup(final int key)
        {
            try
            {
                Thread.sleep(1000);
                return key * key;
            }
            catch (InterruptedException e)
            {
                throw new RuntimeException(e);
            }
        }
    }
}
