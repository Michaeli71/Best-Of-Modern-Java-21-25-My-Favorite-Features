package java25.jep485_stream_gatherers;

import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Supplier;
import java.util.stream.Gatherer;
import java.util.stream.Stream;


public class TripleGathererExample {
    void main()
    {
        IO.println(Stream.of("This", "is", "a", "test").
                          gather(every2ndTriple()).
                          toList());

        IO.println(Stream.of(1, 2, 3, 4, 5).
                          gather(every2ndTriple()).
                          toList());
    }

    <T> Gatherer<T, Void, T> triple_lambda() {
        return new Gatherer<>() {
            @Override
            public Integrator<Void, T, T> integrator() {
                return (_, element, downstream) ->
                        downstream.push(element) && downstream.push(element) &&
                                downstream.push(element);
            }
        };
    }

    <T> Gatherer<T, Object, T> triple_Old() {
        return new Gatherer<T, Object, T>() {
            @Override
            public Integrator<Object, T, T> integrator() {
                return new Integrator<Object, T, T>() {
                    @Override
                    public boolean integrate(Object unusedState, T element,
                                             Downstream<? super T> downstream) {
                        downstream.push(element);
                        downstream.push(element);
                        downstream.push(element);

                        return true;
                    }
                };
            }
        };
    }

    <T> Gatherer<T, Object, T> triple() {
        return new Gatherer<T, Object, T>() {
            @Override
            public Integrator<Object, T, T> integrator() {
                return new Integrator<Object, T, T>() {
                    @Override
                    public boolean integrate(Object unusedState, T element,
                                             Downstream<? super T> downstream) {
                        boolean pushed = downstream.push(element);
                        if (pushed)
                            pushed = downstream.push(element);

                        if (pushed)
                            pushed = downstream.push(element);

                        return pushed;
                    }
                };
            }
        };
    }


    <T> Gatherer<T, AtomicInteger, T> every2ndTriple() {
        return new Gatherer<T, AtomicInteger, T>() {
            @Override
            public Supplier<AtomicInteger> initializer() {
                return () -> new AtomicInteger(0);
            }

            @Override
            public Integrator<AtomicInteger, T, T> integrator() {
                return new Integrator<AtomicInteger, T, T>() {
                    @Override
                    public boolean integrate(AtomicInteger state, T element,
                                             Downstream<? super T> downstream) {
                        boolean pushed = true;
                        if (state.getAndIncrement() % 2 == 0) {
                            pushed = downstream.push(element);
                            if (pushed)
                                pushed = downstream.push(element);

                            if (pushed)
                                pushed = downstream.push(element);
                        }
                        return pushed;
                    }
                };
            }
        };
    }

    <T> Gatherer<T, AtomicInteger, T> every2ndTripleAgain_Old() {
        return Gatherer.ofSequential(
                AtomicInteger::new,
                (state, element, downstream) ->
                {
                    boolean pushed = true;
                    if (state.getAndIncrement() % 2 == 0) {
                        pushed = downstream.push(element);
                        if (pushed)
                            pushed = downstream.push(element);

                        if (pushed)
                            pushed = downstream.push(element);
                    }
                    return pushed;
                }
        );
    }

    public static <T> Gatherer<T, AtomicInteger, T> every2ndTripleAgain() {
        return Gatherer.ofSequential(
                AtomicInteger::new,
                (state, element, downstream) ->
                {
                    if (state.getAndIncrement() % 2 != 0)
                        return true;

                    return downstream.push(element)
                            && downstream.push(element)
                            && downstream.push(element);
                }
        );
    }
}
