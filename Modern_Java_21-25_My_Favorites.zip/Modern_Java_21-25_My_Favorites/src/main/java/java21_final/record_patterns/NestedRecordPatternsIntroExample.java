package java21_final.record_patterns;

/**
 * Beispielprogramm für den Workshop "Best of Java 11/17 bis 20/21/22/23" / das Buch "Java – die Neuerungen in Java 17 LTS, 18 und 19"
 * Sample program for the workshop "Best of Java 11/17 to 20/21/22/23"
 *
 * @author Michael Inden
 * <p>
 * Copyright 2021/2022/2023/2024 by Michael Inden
 */
public class NestedRecordPatternsIntroExample
{    
    record Point(int x, int y) {}
    
    enum Color { RED, GREEN, BLUE }
    record ColoredPoint(Point point, Color color) {}
    record Rectangle(ColoredPoint upperLeft, ColoredPoint lowerRight) {}


    static void printColorOldStyls(Rectangle rect)
    {
        var upperLeft = rect.upperLeft();

        if (upperLeft != null)
        {
            System.out.println(upperLeft.color());
        }
    }

    static void printXAndColorOldStyls(Rectangle rect)
    {
        var upperLeft = rect.upperLeft();
        var lowerRight = rect.lowerRight();

        if (upperLeft != null && upperLeft.point() != null && lowerRight != null)
        {
            System.out.println("x: " + upperLeft.point().x() +
                               " / color: " + lowerRight.color());
        }
    }

    static void printXAndColor(Rectangle rect)
    {
        if (rect instanceof Rectangle(ColoredPoint(Point(int x, int y), Color color),
                                      ColoredPoint(Point point2, Color color2)))
        {
            System.out.println("x: " + x + " / color: " + color2);
        }
    }

    static void printXAndColorST(Rectangle rect)
    {
        if (rect instanceof Rectangle(ColoredPoint(Point(int x, int y), Color color),
                                      ColoredPoint(Point point2, Color color2)))
        {
            System.out.println("x: " + x + " / color: " + color2);
        }
    }

    public static void main(final String[] args)
    {
        var upperLeft = new ColoredPoint(new Point(7, 2), Color.RED);
        var lowerRight = new ColoredPoint(new Point(23, 11), Color.GREEN);

        printXAndColorOldStyls(new Rectangle(upperLeft, lowerRight));
        printXAndColor(new Rectangle(upperLeft, lowerRight));
    }
}

