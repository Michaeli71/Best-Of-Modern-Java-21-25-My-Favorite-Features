package java21_final.virtuals_threads;

import java.time.Duration;
import java.util.concurrent.Executors;

/**
 * Beispielprogramm für den Workshop "Best of Java 11/17 bis 20/21/22/23" / das Buch "Java – die Neuerungen in Java 17 LTS, 18 und 19"
 * Sample program for the workshop "Best of Java 11/17 to 20/21/22/23"
 *
 * @author Michael Inden
 * <p>
 * Copyright 2021/2022/2023/2024 by Michael Inden
 */
public class PlatformThreadsExample
{
    public static void main(final String[] args)
    {
        System.out.println("Start");

        try (var executor = Executors.newCachedThreadPool())
        {
            // Demo: 1_000 // 10_000 // 100_000
            for (int i = 0; i < 1_000; i++)
            {
                final int pos = i;
                executor.submit(() -> {
                    Thread.sleep(Duration.ofSeconds(5));
                    return pos;
                });
            }
        }

        // executor.close() is called implicitly, and waits
        System.out.println("End");
    }
}
